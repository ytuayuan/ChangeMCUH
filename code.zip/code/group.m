    function [Group_DC,rest]=group(DC_iteration,i,n_blk)

    number=2*i;% ÿ��ĸ���
    group=floor(n_blk/number);% ����
    Group_DC = mat2cell(DC_iteration(1:group*number),1,ones(1,group)*number);
    rest=DC_iteration(group*number+1:n_blk);
    tt=1;