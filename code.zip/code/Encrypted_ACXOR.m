function [encrypted_ACXOR]=Encrypted_ACXOR(name_cover,name_enACXOR,keyen)

%% ��ȡ��Ϣ
jpg_obj = jpeg_read(name_cover);
dct = jpg_obj.coef_arrays{1, 1};
qt = jpg_obj.quant_tables{1, 1};
qt = zigzag(qt);
[row, col] = size(dct);
% �����
n_blk = row * col / (8 * 8);
% DCT��
blk_dct = mat2cell(dct,ones(row/8,1)*8,ones(col/8,1)*8);
% % Zigzag���DCT��
% blk_zigzag = cellfun(@(x) zigzag(x), blk_dct,'UniformOutput',false);
% % Zigzag���DCT����м��ʽ
% blk_zrv = cellfun(@(x) get_zrv(x), blk_zigzag,'UniformOutput',false);

%% XOR����ACA
for i=1:n_blk
    blk_dct{i}(1)=0;
    for j=2:64
            if j>1
            ac=blk_dct{i}(j);
                if ac~=0
                   t1=floor(log2(abs(ac)))+1; % ���ĸ���Χ��
                   t2=(2^t1-2^(t1-1))*2; % ��Χ���ж��ٸ���

                   s = RandStream.create('mt19937ar','seed',keyen);   
                   steam=RandStream.setGlobalStream(s);
        %            reset(steam);
                   x=randperm(t2);   %���������������
                   temp=2^(t1-1)-1+x(1);
                   if x(1)<t2/2
                       blk_dct{i}(j)=-1*temp;
                   else
                        blk_dct{i}(j)=temp;
                   end
                end
            end
    end
end
encrypted_ACXOR=cell2mat(blk_dct);

jpg_obj_enXOR = jpg_obj;
jpg_obj_enXOR.coef_arrays{1,1} = encrypted_ACXOR;

jpeg_write(jpg_obj_enXOR,name_enACXOR);
tt=1;