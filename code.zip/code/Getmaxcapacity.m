function [fi_best,rate_best,blk_best,bestc,fi,rate,blk,c]=Getmaxcapacity(u1,u2,name_cover,possible_solutions,num_slt_pks)
% ���ַ���ⵥλ�ļ�������С�ڵ���1

t1=1; step=100;
% ��u2
c(t1)=u2;
[fi(t1),rate(t1),blk(t1)]=GetOpt(name_cover,u2,possible_solutions,num_slt_pks);
if rate(1)<=1
    fi_best=fi(t1);
    rate_best=rate(t1);
    blk_best=blk(t1);
    bestc=u2;
end

if rate(1)>1
    t1=t1+1; high=u2;
    % ��u1
    [fi(t1),rate(t1),blk(t1)]=GetOpt(name_cover,u1,possible_solutions,num_slt_pks);
    c(t1)=u1;
    % �����С��С��1
    if rate(2)<1
        low=u1;
        while low <=high
            mid=floor((low+high)/2);
            t1=t1+1;
             [fi(t1),rate(t1),blk(t1)]=GetOpt(name_cover,mid,possible_solutions,num_slt_pks);
             c(t1)=mid;
             if 1-rate(t1)>=0&1-rate(t1)<=0.2
                  fi_best=fi(t1);
                  rate_best=rate(t1);
                  blk_best=blk(t1);
                  bestc=mid;
                  break;
             elseif rate(t1)>1
                 high=mid-step;
             elseif rate(t1)<1
                 low=mid+step;
             end
        end
        % ������ַ��ҵ��Ķ���С�ģ���ô����֮ǰ�������ҵ�һ��rate<1��
        if low>high 
            pos=find(rate<1);
             fi_best=fi(pos(end));
             rate_best=rate(pos(end));
             blk_best=blk(pos(end));
             bestc=c(pos(end));
        end
    end
    % �����С�Ĵ���1
     if rate(2)>1
          fi_best=fi(t1);
          rate_best=rate(t1);
          blk_best=blk(t1);
          bestc=mid;
     end 
end
end