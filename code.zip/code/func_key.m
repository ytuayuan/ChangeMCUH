function [xe,ue]=func_key(num,key)

% for i=0:63
%     count=0;
%     for j=1:length(num)
%         if i==num(1,j)
%             count=count+1;
%         end
%     end
%     h(i+1)=count;
% end
hashcode=hash2(num,'SHA-512');
hashleft=hashcode(1:64);
hashright=hashcode(65:128);
for i=1:64
    hashleftd(i)=hex2dec(hashleft(i));
    hashleft2{1,i}=bitget(hashleftd(i),4:-1:1);
end
for i=1:64
    hashrightd(i)=hex2dec(hashright(i));
    hashright2{1,i}=bitget(hashrightd(i),4:-1:1);
end
hashleft2d=[];
for i=1:64
    hashleft2d1=hashleft2{1,i};
    hashleft2d=[hashleft2d hashleft2d1];
end
hashright2d=[];
for i=1:64
    hashright2d1=hashright2{1,i};
    hashright2d=[hashright2d hashright2d1];
end
n=0;
for i=1:(256-4)/9
    hashleftgro{1,i}=hashleft2d(9*n+1:9*(n+1));
    n=n+1;
end
hashleftgro{1,29}=hashleft2d(253:256);
n=0;
for i=1:(256-4)/9
    hashrightgro{1,i}=hashright2d(9*n+1:9*(n+1));
    n=n+1;
end
hashrightgro{1,29}=hashright2d(253:256);

num1=0;
for i=1:29
    count=0;
    for j=1:length(hashleftgro{1,i})
        if hashleftgro{1,i}(j) == 1
            count=count+1;
        end
    end
    hashleft1(i)=count;
    num1=num1+hashleft1(i);
end
num2=0;
for i=1:29
    count=0;
    for j=1:length(hashrightgro{1,i})
        if hashrightgro{1,i}(j) == 1
            count=count+1;
        end
    end
    hashright1(i)=count;
    num2=num2+hashright1(i);
end
x1=char(hashright1(:)'+'0');
x2=char(hashleft1(:)'+'0');
hr=str2num(x1);
hl=str2num(x2);
hr=hr*10^-30;
hl=hl*10^-30;
xe=key(1)+hr;
ue=key(2)+hl;
% hr=vpa(hr*10^-31,15);
% hl=vpa(hl*10^-31,15);
% xe= vpa(sym(key(1))+hr,15);
% ue= vpa(sym(key(2))+hl,15);
%      xe=num1/256;%��һ��
%      ue=num2/36;
end
