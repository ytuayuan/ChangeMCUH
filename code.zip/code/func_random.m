function [seq, ind]=func_random(u,x0,n)
% if n==1
% y=1;
% else
% y=x*control(x-1);
% end

seq0=zeros(2,n);
% seq0=sym(seq0);
seq0(1,1)=x0;
seq0(2,1)=1;
for i=2:n
    seq0(1,i)=u*seq0(1,i-1)*(1-seq0(1,i-1));
    seq0(2,i)=i;
end
[seq(1,:),ind]=sort(seq0(1,:));
end

