function [jpg_obj,dct,qt,blk_zigzag,blk_zrv,blk_dct,All_zrv,All_zigzag]=Get_Imagedata(name_cover)
jpg_obj = jpeg_read(name_cover);
dct = jpg_obj.coef_arrays{1, 1};
qt = jpg_obj.quant_tables{1, 1};
qt = zigzag(qt);
[row, col] = size(dct);
% �����
n_blk = row * col / (8 * 8);
% DCT��
blk_dct = mat2cell(dct,ones(row/8,1)*8,ones(col/8,1)*8);
% Zigzag���DCT��
blk_zigzag = cellfun(@(x) zigzag(x), blk_dct,'UniformOutput',false);
% Zigzag���DCT����м��ʽ
blk_zrv = cellfun(@(x) get_zrv(x), blk_zigzag,'UniformOutput',false);
[All_zrv,All_zigzag]=Get_AllData(blk_zrv,blk_zigzag);