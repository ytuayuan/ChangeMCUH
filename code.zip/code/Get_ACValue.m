function [max_ac,min_ac]=Get_ACValue(name_encrypted)
%% �õ�ͼ�����
jpg_obj = jpeg_read(name_encrypted);
dct = jpg_obj.coef_arrays{1, 1};
qt = jpg_obj.quant_tables{1, 1};
%% ����ACϵ��ȡֵ��Χ
% ���
TMax=[];
for u=0:7
    for v=0:7
        temp1=0;temp2=0;
        for i=0:7
            for j=0:7
                t1(i+1,j+1)=cos((2*i+1)*u*pi/16);
                t2(i+1,j+1)=cos((2*j+1)*v*pi/16);
                tt(i+1,j+1)=t1(i+1,j+1)*t2(i+1,j+1);
                te(1)=tt(i+1,j+1)*127;
                te(2)=tt(i+1,j+1)*(-128) ;
                t=max(te);
                tmin=min(te);
                if tt(i+1,j+1)>0
                    to=tt(i+1,j+1)*127;
                    tmino=tt(i+1,j+1)*(-128);
                end
                if tt(i+1,j+1)<=0
                    to=tt(i+1,j+1)*(-128);
                    tmino=tt(i+1,j+1)*127;
                end
                if t~=to&tmin~=tmino
                    sss=1;
                end
                temp1=temp1+t;
                temp2=temp2+tmin;
            end
        end
        tempt=zeros(8,1);
        TMax=[TMax,tempt,tt];
%         figure
%         imshow(tt,[],'InitialMagnification','fit');
        if u==0
            cu=1/sqrt(2);
        else
            cu=1;
        end
        if v==0
            cv=1/sqrt(2);
        else
            cv=1;
        end
        temp1=temp1*cu*cv/4;
        temp2=temp2*cu*cv/4;
        maxd(u+1,v+1)=round(temp1);
        mind(u+1,v+1)=round(temp2);
    end
end
max_ac=round(maxd./qt);
min_ac=round(mind./qt);



% %% ���Է���DCT
% Temp=(maxd(1,2)).*ones(8,8);
% % Temp=[0,15,-3,-2,7,6,1,-1;53,1,-14,-1,-3,0,2,-19;-1,-1,1,-21,2,0,-2,0;2,4,-70,42,-2,-40,-1,0;1,-130,20,2,-2,-1,0,0;-7,-1,1,-1,1,45,1,1;3,-3,0,-6,1,104,-1,5;-1,-2,-2,1,-3,13,3,7];
% Temp1=Temp.*qt;
% % Temp1(1,1)=0;
% for i=0:7
%     for j=0:7
%         temp1=0;temp2=0;
%         for u=0:7
%             for v=0:7
%                  t1(u+1,v+1)=cos((2*i+1)*u*pi/16);
%                 t2(u+1,v+1)=cos((2*j+1)*v*pi/16);
%                 tt(u+1,v+1)=t1(i+1,j+1)*t2(i+1,j+1);
%                  if u==0&v==0
%                      tt(u+1,v+1)= tt(u+1,v+1)*1;
%                 else
%                     tt(u+1,v+1)= tt(u+1,v+1)*1/2;
%                  end
%                 
%                 x(u+1,v+1)=Temp1(u+1,v+1)* tt(u+1,v+1);
%                 temp1=temp1+x(u+1,v+1);
%                
%             end
%         end
% %         tempt=zeros(8,1);
% %         TMax=[TMax,tempt,tt];
% %         figure
% %         imshow(tt,[],'InitialMagnification','fit');
%       f(i+1,j+1)=round(1/4*temp1);
%     end
% end
% TT=f+128;
% imwrite(uint8(TT),'test.tiff');
% III=imread('test.tiff');
% ttt=1;



