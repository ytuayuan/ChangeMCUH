function [DC_samesign,DC_DPCM]=DC_en1(blk_dct,n_blk,xe,ue)

%% ��ȡDCϵ��
DC_All=[];DC_DPCM=zeros(1,n_blk);
t=1;
for i=1:64
    for j=1:64
        DC_All=[DC_All,blk_dct{i,j}(1)];
        if t==1
            DC_DPCM(t)=blk_dct{i,j}(1);
        end
        if t>1
            DC_DPCM(t)=DC_All(t)-DC_All(t-1);
        end
        t=t+1;
    end
end

%% DC ϵ������
% ��ͬ������������Ϊһ��
Group_DC=cell(1,n_blk);
Group_DC{1}(1)=DC_DPCM(1);
t1=1;t2=2;
for i=2:n_blk
    if DC_DPCM(i)*DC_DPCM(i-1)>=0
        Group_DC{t1}(t2)=DC_DPCM(i);
        t2=t2+1;
    end
    if DC_DPCM(i)*DC_DPCM(i-1)<0
        t1=t1+1;t2=1;
        Group_DC{t1}(t2)=DC_DPCM(i);
        t2=t2+1;
    end
end
Group_DC=Group_DC(1:t1);

%% ����
DC_samesign=[];
DC_samesign_en = cellfun(@(x) samesing_en(x,xe,ue), Group_DC,'UniformOutput',false);
for i=1:size(DC_samesign_en,2)
    DC_samesign=[DC_samesign,DC_samesign_en{i}];
end
tt=1;
