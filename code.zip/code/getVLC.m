function vlc=getVLC(img_name)
fidorg = fopen(img_name);
jpg_data = fread(fidorg);
loc_ff = find(jpg_data == 255);    % record the positions of FF.
[len,~] = size(jpg_data);
[~,~,blk_h,blk_w] = get_img_size(jpg_data,loc_ff);
blk_num = blk_h * blk_w;
%% Parse the Huffman table (DHT segment, started from FFC4).
loc_c4 = find(jpg_data(loc_ff+1,1) == 196);
if length(loc_c4)>1
    data_huff_dc = get_dht(loc_ff,jpg_data,fidorg,1);  % segment of the huffman table of DC.
    table_huff_dc = get_huff_dc_table(data_huff_dc);
    data_huff_ac = get_dht(loc_ff,jpg_data,fidorg,2);   % segment of the huffman table of AC.
    table_huff_ac = get_huff_ac_table(data_huff_ac);
else
    error('The number of Huffman table specifications is smaller than 2!');
    %     [huff_tbl_dc,huff_tbl_ac] = fun_read_huff(loc_ff,loc_c4,jpg_data,fidorg);
    % 	tdchufftbl = fun_huff_dctable(huff_tbl_dc);
    % 	tachufftbl = fun_huff_actable(huff_tbl_ac);	%run - category - length - base code length -  base code
end
%% Parse the entropy-coded data.
dec_ecs = dlt_zero(get_ecs(loc_ff,jpg_data,fidorg));
bin_ecs = int2bin(dec_ecs,8);
[m,n] = size(bin_ecs);
bin_ecs = reshape(bin_ecs.',[1 m*n]);flag = 1;
dc_app_len = zeros(blk_num,1);
dc_code = cell(blk_num,1);  % dc_code includes huffman bits and appended bits.
ac_code = cell(blk_num,1);  % ac_code includes huffman bits and appended bits.
dc_pos = ones(blk_num+1,1); % dc_pos includes the position of dc_code.
ac_pos = ones(blk_num+1,1); % ac_pos includes the position of ac_code.
while flag <= blk_num
    [ac_pos(flag),dc_app_len(flag,1),dc_code{flag}] = parse_dc(bin_ecs, table_huff_dc, dc_pos(flag));
    [dc_pos(flag+1), ac_code{flag}] = parse_ac(bin_ecs, table_huff_ac, ac_pos(flag));
    flag = flag + 1;
end
dc_pos(end) = [];ac_pos(end) = [];
%% Parse the VLCs.
freq_vlc_used = zeros(162,1);
vlc_category = cell(1,16);
for i = 1 : blk_num
    for j = 1 : length([ac_code{i,1}{:,1}])
        cur_row = ac_code{i,1}{j,1};
        freq_vlc_used(cur_row,1) = freq_vlc_used(cur_row,1) + 1;
    end
end
for i=1:16
    vlc_category{:,i} = (reshape(freq_vlc_used(find(table_huff_ac(:,4) == i)),1,[]));
    num_unused = length(find(vlc_category{:,i}==0));
    num_used = length(vlc_category{:,i}) - num_unused;
end
vlc(:,1:2) = table_huff_ac(:,1:2);
vlc(:,4) = table_huff_ac(:,4);
flag = 1;
for i=1:16
    if(~isempty(vlc_category{1,i}))
        num_vlc_category = length(vlc_category{1,i});
        for j = 1 : num_vlc_category
            vlc(flag,3) = vlc_category{1,i}(1,j);
            flag = flag + 1;
        end
    end
end